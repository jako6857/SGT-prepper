export default { content: ['./src/**/*.{html,js,ts,tsx}'] };
